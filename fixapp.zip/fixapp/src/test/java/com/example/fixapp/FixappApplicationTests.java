package com.example.fixapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FixappApplicationTests {

	@Test
	void contextLoads() {
	}

}
